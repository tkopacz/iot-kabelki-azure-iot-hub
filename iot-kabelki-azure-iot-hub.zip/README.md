#Demos for conferences about (Windows) IoT, Azure Iot Hub, Stream Analytics
#Date: 2015-10-09
