# Initial driver for LCD 1602 (16x2) with I2C interface
